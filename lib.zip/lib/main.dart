import 'package:cricket_app/cricbuzz-APIs/ICC%20_rankings/icc_ranking_homepage.dart';
import 'package:cricket_app/cricbuzz-APIs/player_search/search_player_homepage.dart';
import 'package:flutter/material.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
// https://rapidapi.com/cricketapilive/api/cricbuzz-cricket/playground/apiendpoint_1c2ebd9c-e2a7-45fd-8002-10181f6771f4
Future<void> main() async {
  await dotenv.load();
  runApp(CricketNewsApp());
}

class CricketNewsApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(primarySwatch: Colors.green),
      home: SearchPlayerHomepage(),
    );
  }
}


      // API kes.
// 9a2ebd60e4msh1c91eedcc28797fp1a197bjsne5ea8f72b7e8
// 4c28db685amsh0a6bc2cf6d81cd0p12e0fajsn6e3ced662540
// fae91668c1msh0a972110c87d672p13554cjsn7e2bbc4e70df
// 9a2ebd60e4msh1c91eedcc28797fp1a197bjsne5ea8f72b7e8